function generatePassword(length = 12) {
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+[]{}|;:',.<>?";
    let password = "";
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        password += charset[randomIndex];
    }
    return password;
}

function isStrongPassword(password) {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return regex.test(password);
}

function updateStrengthBar(password) {
    let strength = 0;

    if (password.length >= 8) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/\d/.test(password)) strength++;
    if (/[@$!%*?&]/.test(password)) strength++;

    const strengthBar = document.getElementById("strengthBar");
    strengthBar.style.width = `${strength * 20}%`;

    const strengthText = document.getElementById("strengthText");
    switch (strength) {
        case 0:
        case 1:
            strengthText.textContent = "Senha Fraca";
            strengthBar.style.backgroundColor = "red";
            break;
        case 2:
            strengthText.textContent = "Senha Média";
            strengthBar.style.backgroundColor = "yellow";
            break;
        case 3:
        case 4:
        case 5:
            strengthText.textContent = "Senha Forte";
            strengthBar.style.backgroundColor = "green";
            break;
    }
}

document.getElementById("generateBtn").addEventListener("click", () => {
    const password = generatePassword();
    document.getElementById("generatedPassword").value = password;
    updateStrengthBar(password);
});

document.getElementById("validateBtn").addEventListener("click", () => {
    const password = document.getElementById("passwordInput").value;
    const result = isStrongPassword(password);
    const validationResult = document.getElementById("validationResult");

    if (result) {
        validationResult.textContent = "A senha é forte!";
        validationResult.style.color = "green";
    } else {
        validationResult.textContent = "A senha não é forte! (mínimo 8 caracteres, 1 maiúscula, 1 minúscula, 1 número e 1 caractere especial)";
        validationResult.style.color = "red";
    }
    updateStrengthBar(password);
});

document.getElementById("passwordInput").addEventListener("input", (event) => {
    updateStrengthBar(event.target.value);
});